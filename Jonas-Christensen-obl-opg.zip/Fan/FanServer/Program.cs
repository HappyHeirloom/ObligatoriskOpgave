﻿using System;

namespace FanServer
{
    class Program
    {
        static void Main(string[] args)
        {
            Server.StartServer();
        }
    }
}
